from collections import deque

import Grid2D
from Recherche import *
from Grid2D import *

ROWS = 20  # Nombres de lignes
COLS = 30  # Nombres de Colones

class IDFS(Recherche):

    def __init__(self):
        pass

    def solve_idfs(self, dr, dc, solution, max_depth):
        parents = [[None for r in range(COLS)] for c in range(ROWS)]

        ouvert = deque()
        ouvert.append((dr, dc))
        profondeur = 0

        while ouvert:
            r, c = ouvert.pop()
            solution.visit(r, c)
            self.draw_solution(solution)

            if solution.is_solved():
                # Récupération du chemin direct menant à la sortie
                solution.processed = [(r, c)]
                while parents[r][c]:
                    solution.optimal(r, c)
                    solution.processed.append(parents[r][c])
                    r, c = parents[r][c]

                solution.optimal(0, 0)
                solution.processed.append((0, 0))

                # Tracé en jaune du chemin qui a mené à la sortie
                self.draw_solution(solution)
                return
            # Retour arrière pour traiter les noeuds non visités dans d'autres branches
            if len(ouvert) > 0 and (not solution.next_cells(r, c) or profondeur == max_depth):
                solution.backtrack(r, c)
                self.draw_solution(solution)
                while parents[r][c]:
                    r, c = parents[r][c]
                    profondeur = profondeur - 1
                    if solution.next_cells(r, c):
                        solution.backtrack(r, c)
                        self.draw_solution(solution)
                        break
                    solution.backtrack(r, c)
                    self.draw_solution(solution)

                continue # Aller au pochain noued dans ouvert

            #il y a encore des noeuds à visiter pour l'itération courante
            if profondeur < max_depth and solution.next_cells(r, c):
                for nr, nc in solution.next_cells(r, c):
                    ouvert.append((nr, nc))
                    parents[nr][nc] = (r, c)

                profondeur = profondeur + 1


            #Solution non trouvée à cette profondeur, on itére avec une profondeur supérieure
            if len(ouvert) == 0:
                max_depth = max_depth + 1
                #réinitialiser le labyrinthe
                Grid2D.Grille2D.btn_idfs(self, max_depth)
