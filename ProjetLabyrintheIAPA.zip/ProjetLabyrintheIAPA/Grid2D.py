from tkinter import *

from BFS import BFS
from DFS import DFS
from IDFS import IDFS
from ASTAR import astar
from random import choice
from threading import Thread
from time import sleep
import sys
from math import sqrt

# maze configuration
ROWS = 20  # Nombres de lignes
COLS = 30  # Nombres de Colones
SIZE = 30  # Longueur d'une case
MARGIN = SIZE / 2  # L'épaisseur de la marge
CANVAS_WIDTH = COLS * SIZE + SIZE  # La longueur du canvas
CANVAS_HEIGHT = ROWS * SIZE + SIZE  # La largeur du canvas
BORDER = 2  # L'épaisseur de la bordure des murs

# search states
NOTVISITED = 0      # etat non visité
VISITING = 1        # etat visité
BACKTRACKED = 2     # etat visité deux fois
OPTIMAL = 3         # etat visité par le chemin optimal qui mène à la sortie
REBACKTRACKED = 4   # etat visité trois fois

# up, down, right, left
DIRS = ((-1, 0), (1, 0), (0, 1), (0, -1))  # Direction

class Grille2D:
    def __init__(self):
        self.init_ui()

    def init_ui(self):
        self.window = Tk()  # Instantiation d'un objet de la classe Tk
        self.window.title('Labyrinthe')  # Nom de la fenetre
        self.window.resizable(False, False)  # Interdire le redimensionnement de la fenêtre de Tkinter

        fm = Frame(self.window)
        Button(fm, text="generer labyrinthe", command=self.btn_generate).pack(side=LEFT)
        Button(fm, text="dfs", command=self.btn_dfs).pack(side=RIGHT)
        Button(fm, text="bfs", command=self.btn_bfs).pack(side=RIGHT)  # Création des boutons
        Button(fm, text="Idfs", command=self.btn_idfs).pack(side=RIGHT)
        Button(fm, text="astar", command=self.btn_astar).pack(side=RIGHT)
        fm.pack(fill=BOTH, expand=YES)
        """
            L' option de fill indique au gestionnaire que le widget
            veut remplir tout l'espace qui lui est assigné.
            La valeur contrôle comment remplir l'espace; BOTH signifie que le
            widget doit s'étendre à la fois horizontalement et verticalement

            L' option expand indique au gestionnaire d'attribuer 
            un espace supplémentaire à la boîte de widget    
        """
        self.canvas = Canvas(self.window, width=CANVAS_WIDTH, height=CANVAS_HEIGHT,
                             background="orange", bd=0, highlightthickness=0,
                             relief='ridge')  # Création du canvas contenant le labyrinthe
        self.canvas.pack()  # Tkinter redimensionne la fenêtre aussi petite que possible tout en englobant entièrement le widget

        self.btn_generate()  # Genere le labyrinthe

        self.window.mainloop()  # Ecoute les evenement

    def btn_generate(self):
        self.maze = [[{'visited': False, 'adj': []}
                      for r in range(COLS)] for c in
                     range(ROWS)]  # Création d'une matrice ou chaque case contient une liste
        self.create_maze(0, 0)
        self.draw_maze()

    def btn_dfs(self):
        sys.setrecursionlimit(
            ROWS * COLS)  # défini la profondeur maximale de la pile d'interpréteurs Python à la limite requise qu'est la taille de la fenetre en case
        self.draw_maze()

        def async_():
            solution = Solution(self.maze, ROWS - 1, COLS - 1)  # Instantiation d'un objet de classe SOLUTION
            DFS.solve_dfs(self, 0, 0, solution)

        Thread(target=async_).start()  # Parallélisme basé sur les fils d’exécution

    def btn_idfs(self, depth = 10):
        self.draw_maze()

        def async_():
            solution = Solution(self.maze, ROWS - 1, COLS - 1)

            IDFS.solve_idfs(self, 0, 0, solution, depth)

        Thread(target=async_).start()

    def btn_astar(self):
        self.draw_maze()

        def async_():
            solution = Solution(self.maze, ROWS - 1, COLS - 1)
            start = (0, 0)
            #but = (ROWS - 1, COLS - 1)
            astar.solve_astar(self, start, solution)

        Thread(target=async_).start()

    def btn_bfs(self):
        self.draw_maze()

        def async_():
            solution = Solution(self.maze, ROWS - 1, COLS - 1)

            BFS.solve_bfs(self, 0, 0, solution)

        Thread(target=async_).start()

    def create_maze(self, r, c):
        self.maze[r][c]['visited'] = True  # Affecte la valeur visited = "True" dans la case courante
        stack = []  # Créer une pile de type tableau

        while True:
            adj = []  # Créer un tableau contenant les indices de chaque voisins de la case courante
            for d in DIRS:
                nr, nc = r + d[0], c + d[1]  # nr voisinLigne, nc voisinColonne
                if 0 <= nr < len(self.maze) and 0 <= nc < len(self.maze[0]) and not self.maze[nr][nc]['visited']:
                    adj.append((nr, nc))  # Ajoute les voisins dans adj

            if adj:  # Si adj est non vide
                nr, nc = choice(adj)  # choisis aléatoirement une case dans le tableau adj
                self.maze[r][c]['adj'].append((nr, nc))  # Ajoute la valeur adj =(nr,nc) dans la case courante
                stack.append((r, c))  # Ajoutez dans la pile le voisin
                r, c = nr, nc  # Passe mainetant à la case voisine choisis
                self.maze[r][c]['visited'] = True
            elif not stack:  # Si stack est vide
                break
            else:
                r, c = stack.pop()  # Retire le dernier element et l'affecte à r et c

    def draw_maze(self):  # Dessine le labyrinthe
        # clear canvas
        self.canvas.create_rectangle(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT, fill='black')

        # punch out path
        for r in range(ROWS):
            for c in range(COLS):
                for ar, ac in self.maze[r][c]['adj']:
                    y0 = min(r, ar) * SIZE + BORDER + MARGIN
                    x0 = min(c, ac) * SIZE + BORDER + MARGIN
                    y1 = max(r, ar) * SIZE + (SIZE - BORDER) + MARGIN
                    x1 = max(c, ac) * SIZE + (SIZE - BORDER) + MARGIN
                    self.canvas.create_rectangle(x0, y0, x1, y1, fill="white", outline='')
        self.canvas.create_rectangle(BORDER + MARGIN, BORDER + MARGIN, (SIZE - BORDER) + MARGIN, (SIZE - BORDER) + MARGIN, fill="yellow", outline='')
        self.canvas.create_rectangle(CANVAS_WIDTH - BORDER - MARGIN - SIZE, CANVAS_HEIGHT - BORDER - MARGIN - SIZE, CANVAS_WIDTH - BORDER - MARGIN, CANVAS_HEIGHT - BORDER - MARGIN, fill="red", outline='')

    def draw_solution(self, solution):
        colors = {VISITING: 'grey', NOTVISITED: 'white', BACKTRACKED: 'green', OPTIMAL: 'yellow', REBACKTRACKED: 'blue'}

        # only draw whats changed since last iteration
        for r, c in solution.processed:
            x0 = c * SIZE + MARGIN + BORDER + 1
            y0 = r * SIZE + MARGIN + BORDER + 1
            x1 = c * SIZE + MARGIN + SIZE - BORDER -1
            y1 = r * SIZE + MARGIN + SIZE - BORDER -1
            self.canvas.create_rectangle(x0, y0, x1, y1, fill=colors[solution.states[r][c]], outline='')

        # vider les noeuds de processed pour la prochaine itération
        solution.processed.clear()
        sleep(0.05)

class Solution:
    def __init__(self, m, gr, gc):
        self.m = m
        self.goal_r = gr  # LigneBut
        self.goal_c = gc  # ColonneBut
        self.states = [[NOTVISITED for r in range(COLS)] for c in
                       range(ROWS)]  # Initialise tout les etats des case à NonVisité
        self.processed = []  # Créer un tableau p

    def heuristic(self, p1, p2):
        return sqrt((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2)

    def getNeighbor(self, node):
        r, c = node
        adj = self.m[r][c]['adj']
        return list(filter(lambda rc: self.states[rc[0]][rc[1]] == NOTVISITED or self.states[rc[0]][rc[1]] == VISITING, adj))

    def is_solved(self):
        return self.states[self.goal_r][self.goal_c] == VISITING

    def visit(self, r, c):
        if self.states[r][c] == VISITING: #A revoir
            self.backtrack(r, c)
        else:
            self.states[r][c] = VISITING
        self.processed.append((r, c))

    def next_cells(self, r, c):
        adj = self.m[r][c]['adj']
        return list(filter(lambda rc: self.states[rc[0]][rc[1]] == NOTVISITED, adj))

    def backtrack(self, r, c):
        if self.states[r][c] == BACKTRACKED:
            self.states[r][c] = REBACKTRACKED
        else:
            self.states[r][c] = BACKTRACKED
        self.processed.append((r, c))

    def optimal(self, r, c):
        self.states[r][c] = OPTIMAL