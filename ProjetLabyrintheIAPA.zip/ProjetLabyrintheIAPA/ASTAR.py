from Recherche import *
from queue import PriorityQueue
from Grid2D import *

ROWS = 20  # Nombres de lignes
COLS = 30  # Nombres de Colones

class astar(Recherche):
    def __init__(self):
        pass

    def solve_astar(self, start, finish):

        closed_set = []
        open = PriorityQueue()
        parent_trace = {start: None}
        nodes_cost = {start: 0}
        open.put((0, start))

        while not open.empty():
            #Récupération du noeud ayant le meilleur coût
            cout, current_node = open.get()

            if  current_node not in closed_set or cout < nodes_cost[current_node]:
                if finish.is_solved():
                    # Récupération du chemin direct menant à la sortie
                    current_node = (ROWS - 1, COLS - 1)
                    finish.optimal(current_node[0], current_node[1])
                    finish.processed.append((current_node[0], current_node[1]))
                    self.draw_solution(finish)
                    while parent_trace[current_node]:
                        current_node = parent_trace[current_node]
                        finish.optimal(current_node[0], current_node[1])
                        finish.processed.append((current_node[0], current_node[1]))
                        self.draw_solution(finish)

                    return

                closed_set.append(current_node)
                finish.visit(current_node[0], current_node[1])
                self.draw_solution(finish)

                for neighbor in finish.getNeighbor(current_node):
                    #Calcule de f = g + h de chaque voisin du noeud courant
                    neighbor_cost = cout + 1
                    neighbor_h = finish.heuristic(neighbor, (ROWS - 1, COLS - 1))
                    neighbor_f = neighbor_cost + neighbor_h

                    parent_trace[neighbor] = current_node

                    open.put((neighbor_f, neighbor))
