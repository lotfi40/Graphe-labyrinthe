
class case:
    def __init__(self, wcell):
        self.wcell = wcell