from abc import ABCMeta, abstractmethod


class Recherche():
    __metaclass__ = ABCMeta

    @abstractmethod
    def solve(self, start, finish):
        pass

