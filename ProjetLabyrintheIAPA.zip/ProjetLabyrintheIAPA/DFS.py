from collections import deque
from Recherche import *
from Grid2D import *

ROWS = 20  # Nombres de lignes
COLS = 30  # Nombres de Colones

class DFS(Recherche):

    def __init__(self):
        pass

    def solve_dfs(self, r, c, solution):
        parents = [[None for r in range(COLS)] for c in range(ROWS)]

        ouvert = deque()
        ouvert.append((r, c))

        while ouvert:
            r, c = ouvert.pop()
            solution.visit(r, c)
            self.draw_solution(solution)

            if solution.is_solved():
                # Récupération du chemin qui a mené à la sortie
                solution.processed = [(r, c)]
                while parents[r][c]:
                    solution.optimal(r, c)
                    solution.processed.append(parents[r][c])
                    r, c = parents[r][c]

                solution.optimal(0, 0)
                solution.processed.append((0, 0))

                # Tracé en jaune du chemin qui a mené à la sortie
                self.draw_solution(solution)
                return

            #tracer le chemin de retour arrière : couleur vert pour la 2eme visite et blue pour la 3eme
            if not solution.next_cells(r, c):
                solution.backtrack(r, c)
                self.draw_solution(solution)
                while parents[r][c]:
                    r, c = parents[r][c]
                    if solution.next_cells(r, c):
                        solution.backtrack(r, c)
                        self.draw_solution(solution)
                        break
                    solution.backtrack(r, c)
                    self.draw_solution(solution)

            for nr, nc in solution.next_cells(r, c):
                ouvert.append((nr, nc))
                parents[nr][nc] = (r, c)

