

"""
    Projet module IAPA
        Groupe :  BRAHMI Sabrina
                  AMRANE Lotfi
                  ZIANI Sifax
"""

from Grid2D import Grille2D

if __name__ == '__main__':
    Grille2D()
