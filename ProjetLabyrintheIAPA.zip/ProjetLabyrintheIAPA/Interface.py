from ASTAR import astar
from BFS import BFS
from DFS import DFS
from IDFS import IDFS


class interface(DFS, BFS, IDFS, astar):
    pass
