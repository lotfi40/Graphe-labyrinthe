from collections import deque

from Grid2D import *
from Recherche import *

ROWS = 20  # Nombres de lignes
COLS = 30  # Nombres de Colones

class BFS(Recherche):
    def __init__(self):
        pass

    def solve_bfs(self, r, c, solution):
        parents = [[None for r in range(COLS)] for c in range(ROWS)]

        ouvert = deque()
        ouvert.append((r, c))

        while ouvert:
            r, c = ouvert.popleft()
            solution.visit(r, c)
            self.draw_solution(solution)

            if solution.is_solved():
                # Récupération du chemin qui a mené à la sortie
                solution.processed = [(r, c)]
                while parents[r][c]:
                    solution.optimal(r, c)
                    solution.processed.append(parents[r][c])
                    r, c = parents[r][c]

                solution.optimal(0, 0)
                solution.processed.append((0, 0))

                # Tracé en bleu du chemin qui a mené à la sortie
                self.draw_solution(solution)
                return

            for nr, nc in solution.next_cells(r, c):
                ouvert.append((nr, nc))
                parents[nr][nc] = (r, c)
